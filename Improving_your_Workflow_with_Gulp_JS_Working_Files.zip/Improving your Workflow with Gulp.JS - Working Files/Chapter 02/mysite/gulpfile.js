// Gulp.js configuration

// include gulp and plugins
var
	gulp = require('gulp');

// file locations
var
	source = 'source/',
	dest = 'build/';

// default task
gulp.task('default', function() {

});
