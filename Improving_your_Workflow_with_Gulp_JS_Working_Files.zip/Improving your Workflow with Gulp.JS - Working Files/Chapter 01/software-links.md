Essential software
==================

Node.js:
http://nodejs.org/download/

Install Node.js from a package manager:
https://github.com/joyent/node/wiki/Installing-Node.js-via-package-manager


Code Editors / IDEs
===================

Atom:
https://atom.io/

Brackets:
http://brackets.io/

Notepad++ (Windows only):
http://notepad-plus-plus.org/

SublimeText:
http://www.sublimetext.com/


Web Browsers
===========

Chrome:
http://www.google.com/chrome

Firefox:
http://firefox.com/

Opera:
http://opera.com/

Modern.IE (cross-platform IE testing):
https://www.modern.ie/en-gb


Virtual Machine Software
========================

VirtualBox:
https://www.virtualbox.org/


Windows Terminal Software
=========================

ConEmu:
https://code.google.com/p/conemu-maximus5/

Putty SSH client:
http://www.chiark.greenend.org.uk/~sgtatham/putty/


Graphics Packages
=================

XnView:
http://www.xnview.com/
